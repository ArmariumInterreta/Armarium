get_same_names = function() {
  # Seats that had two incarnations.
  #
  # The following assumes that no seat has had three incarnations, so that indicating
  # the start year of the second incarnation is sufficient information to describe any
  # seat name.
  
  same_names = list()
  same_names[[1]] = list(seat = "Angas", start2 = 1949)
  same_names[[2]] = list(seat = "Burke", start2 = 1969)
  same_names[[3]] = list(seat = "Cook", start2 = 1969)
  same_names[[4]] = list(seat = "Corinella", start2 = 1990)
  same_names[[5]] = list(seat = "Isaacs", start2 = 1969)
  same_names[[6]] = list(seat = "Oxley", start2 = 1949)
  same_names[[7]] = list(seat = "Parkes", start2 = 1984)
  same_names[[8]] = list(seat = "Reid", start2 = 2010)
  same_names[[9]] = list(seat = "Scullin", start2 = 1969)
  same_names[[10]] = list(seat = "Watson", start2 = 1993)
  same_names[[11]] = list(seat = "Riverina", start2 = 1993)
  same_names[[12]] = list(seat = "Canberra", start2 = 2019)
  
  return(same_names)
}


get_group_seats = function() {
  # Re-namings or replacements.
  group_seats = list()
  group_seats[[1]] = list(seat = "Goldstein", older = "Balaclava")
  group_seats[[2]] = list(seat = "Ballarat", older = "Ballaarat")
  group_seats[[3]] = list(seat = "Calare", older = "Canobolas")
  group_seats[[4]] = list(seat = "Scullin2", older = "Darebin")
  group_seats[[5]] = list(seat = "Braddon", older = "Darwin")
  group_seats[[6]] = list(seat = "Hotham", older = "Higinbotham")
  group_seats[[7]] = list(seat = "Kingsford Smith", older = "Kingsford-Smith")
  group_seats[[8]] = list(seat = "Reid2", older = "Lowe")
  group_seats[[9]] = list(seat = "Griffith", older = "Oxley1")
  group_seats[[10]] = list(seat = "McMahon", older = "Prospect")
  group_seats[[11]] = list(seat = "Riverina-Darling", older = "Riverina1")
  group_seats[[12]] = list(seat = "Watson1", older = "South Sydney")
  group_seats[[13]] = list(seat = "Lyons", older = "Wilmot")
  group_seats[[14]] = list(seat = "Whitlam", older = "Throsby")
  group_seats[[15]] = list(seat = "Fenner", older = "Fraser")
  group_seats[[16]] = list(seat = "Bean", older = "Canberra1")
  group_seats[[17]] = list(seat = "Clark", older = "Denison")
  group_seats[[18]] = list(seat = "Cooper", older = "Batman")
  group_seats[[19]] = list(seat = "Macnamara", older = "Melbourne Ports")
  group_seats[[20]] = list(seat = "Monash", older = "McMillan")
  group_seats[[21]] = list(seat = "Nicholls", older = "Murray")
  
  return(group_seats)
}


check_same_name = function(input_seat, year) {
  # Much like replace_party_abbrevs() in merge_exact.R, but here
  # it only works for a single input_seat
  
  same_names = get_same_names()
  
  for (i in seq_along(same_names)) {
    if (input_seat == same_names[[i]]$seat) {
      if (year < same_names[[i]]$start2) {
        output_seat = sprintf("%s1", input_seat)
        return(output_seat)
      } else {
        output_seat = sprintf("%s2", input_seat)
        return(output_seat)
      }
    }
  }
  
  return(input_seat)
}


check_group_seat = function(input_seat) {
  group_seats = get_group_seats()
  
  for (i in seq_along(group_seats)) {
    if (input_seat %in% group_seats[[i]]$older) {
      output_seat = group_seats[[i]]$seat
      return(output_seat)
    }
  }
  
  return(input_seat)
}
