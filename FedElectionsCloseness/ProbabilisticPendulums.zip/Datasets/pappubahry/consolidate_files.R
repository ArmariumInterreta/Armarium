# Script to put together the final set of csv files in ~/consolidated.

library(readr)
library(dplyr)

setwd(".")

source("tpp_estimates/aux_functions.R")

exact_folder = "exact_data"
tpp_est_folder = "tpp_estimates"
flow_est_folder = "flow_estimates"
out_folder = "consolidated"

prim_files = list.files(path=exact_folder, pattern="prim_[0-9]{4}\\.csv")

years = as.numeric(gsub("[^0-9]", "", prim_files))

for (year in years) {
  print(year)
  
  # Primary votes: just re-order the seats.
  infile_prim = sprintf("%s/prim_%d.csv", exact_folder, year)
  outfile_prim = sprintf("%s/prim_%d.csv", out_folder, year)
  
  prim.df = read_csv(infile_prim)
  prim.df$count = seq_along(prim.df$Seat)
  prim.df = prim.df[with(prim.df, order(Seat, count)), ]
  prim.df = subset(prim.df, select = -count)
  
  write.csv(prim.df, file=outfile_prim, row.names=FALSE)
  
  infile_turnout = sprintf("%s/turnout_%d.csv", exact_folder, year)
  outfile_turnout = sprintf("%s/turnout_%d.csv", out_folder, year)
  
  turnout.df = read_csv(infile_turnout)
  turnout.df = turnout.df[with(turnout.df, order(Seat)), ]
  write.csv(turnout.df, file=outfile_turnout, row.names=FALSE)
  
  if (year >= 1919) {
    infile_tcp = sprintf("%s/%s_%d.csv", exact_folder, tcp_name(year), year)
    outfile_tcp = sprintf("%s/%s_%d.csv", out_folder, tcp_name(year), year)
    
    tcp.df = read_csv(infile_tcp)
    
    for (i in seq_along(tcp.df$Seat)) {
      tcp_parties = c(tcp.df$Party1[i], tcp.df$Party2[i])
      tpp_i = tpp_indices(tcp_parties)
      
      if (tpp_i[2] == 1) {
        # ALP is party1; leave as is.
      } else {
        # Swap Party1 and Party2
        party2 = tcp.df$Party2[i]
        cand2 = tcp.df$Candidate2[i]
        votes2 = tcp.df$Votes2[i]
        vote_perc2 = tcp.df$Vote_perc2[i]
        
        tcp.df$Party2[i] = tcp.df$Party1[i]
        tcp.df$Candidate2[i] = tcp.df$Candidate1[i]
        tcp.df$Votes2[i] = tcp.df$Votes1[i]
        tcp.df$Vote_perc2[i] = tcp.df$Vote_perc1[i]
        
        tcp.df$Party1[i] = party2
        tcp.df$Candidate1[i] = cand2
        tcp.df$Votes1[i] = votes2
        tcp.df$Vote_perc1[i] = vote_perc2
      }
    }
    
    tcp.df = tcp.df[with(tcp.df, order(Seat)), ]
    
    write.csv(tcp.df, file=outfile_tcp, row.names=FALSE)
    
    
    if (year <= 1980) {
      infile_just_tpp = sprintf("%s/tpp_%d.csv", tpp_est_folder, year)

      # No need to have the 'year' field which I left in the TPP files
      # during estimation for some reason....
      
      just_tpp.df = read_csv(infile_just_tpp)
      just_tpp.df = just_tpp.df[c("Seat","TPP_ALP","TPP_ALP_perc","TPP_LNP","TPP_LNP_perc","TPP_est_type")]
    } else {
      # Create the just_tpp file from tcp.df; since 1983 these files are
      # really TPP files anyway.
      just_tpp.df = transmute(tcp.df,
                              Seat = Seat,
                              TPP_ALP = Votes1,
                              TPP_ALP_perc = Vote_perc1,
                              TPP_LNP = Votes2,
                              TPP_LNP_perc = Vote_perc2,
                              TPP_est_type = "exact")
      
      # Manual add for Newcastle 1998:
      if (year == 1998) {
        just_tpp.df = rbind(just_tpp.df,
                            data.frame(Seat = "Newcastle",
                                       TPP_ALP = 40709,
                                       TPP_ALP_perc = 62.42,
                                       TPP_LNP = 24514,
                                       TPP_LNP_perc = 37.58,
                                       TPP_est_type = "guess"))
      }
      
      just_tpp.df = just_tpp.df[with(just_tpp.df, order(Seat)), ]
    }
    
    outfile_just_tpp = sprintf("%s/just_tpp_%d.csv", out_folder, year)
    write.csv(just_tpp.df, file=outfile_just_tpp, row.names=FALSE)
    
    # Preferences: just re-order the seats
    infile_prefs = sprintf("%s/prefs_%d.csv", exact_folder, year)
    outfile_prefs = sprintf("%s/prefs_%d.csv", out_folder, year)
    
    prefs.df = read_csv(infile_prefs)
    
    prefs.df = read_csv(infile_prefs)
    prefs.df$counter = seq_along(prefs.df$Seat)
    prefs.df = prefs.df[with(prefs.df, order(Seat, counter)), ]
    prefs.df = subset(prefs.df, select = -counter)
    
    write.csv(prefs.df, file=outfile_prefs, row.names=FALSE)
    
    
    if (year >= 1996) {
      infile_flow = sprintf("%s/flow_%d.csv", exact_folder, year)
      outfile_flow = sprintf("%s/flow_%d.csv", out_folder, year)
      
      flow.df = read_csv(infile_flow)
      flow.df$Calc_type = "Exact"
    } else {
      infile_flow = sprintf("%s/flow_%d.csv", flow_est_folder, year)
      outfile_flow = sprintf("%s/flow_%d.csv", out_folder, year)
      flow.df = read_csv(infile_flow)
    }
    
    for (i in seq_along(flow.df$Seat)) {
      tcp_parties = c(flow.df$To_party1[i], flow.df$To_party2[i])
      tpp_i = tpp_indices(tcp_parties)
      
      if (tpp_i[2] == 1) {
        # ALP is party1; leave as is.
      } else {
        # Swap Party1 and Party2
        party2 = flow.df$To_party2[i]
        cand2 = flow.df$To_candidate2[i]
        votes2 = flow.df$Votes2[i]
        vote_perc2 = flow.df$Vote_perc2[i]
        
        flow.df$To_party2[i] = flow.df$To_party1[i]
        flow.df$To_candidate2[i] = flow.df$To_candidate1[i]
        flow.df$Votes2[i] = flow.df$Votes1[i]
        flow.df$Vote_perc2[i] = flow.df$Vote_perc1[i]
        
        flow.df$To_party1[i] = party2
        flow.df$To_candidate1[i] = cand2
        flow.df$Votes1[i] = votes2
        flow.df$Vote_perc1[i] = vote_perc2
      }
    }
    
    flow.df$counter = seq_along(flow.df$Seat)
    flow.df = flow.df[with(flow.df, order(Seat, counter)), ]
    flow.df = subset(flow.df, select = -counter)
    
    write.csv(flow.df, file=outfile_flow, row.names=FALSE)
  }
}

# And finally, the unopposed divisions.

infile_unopposed_1 = sprintf("%s/unopposed_divisions_pre1919.csv", tpp_est_folder)
infile_unopposed_2 = sprintf("%s/unopposed_divisions.csv", tpp_est_folder)
outfile_unopposed = sprintf("%s/unopposed_divisions.csv", out_folder)

unopposed_1.df = read_csv(infile_unopposed_1)
unopposed_2.df = read_csv(infile_unopposed_2)
unopposed.df = rbind(unopposed_1.df, unopposed_2.df)
unopposed.df = unopposed.df[with(unopposed.df, order(Year, Seat)), ]

write.csv(unopposed.df, file=outfile_unopposed, row.names=FALSE)
