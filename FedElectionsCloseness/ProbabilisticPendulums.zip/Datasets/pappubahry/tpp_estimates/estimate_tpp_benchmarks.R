# Script to create benchmark TPP estimates for 1983-2013.
# Assumes 50-50 preference split on all seats.

library(readr)
library(dplyr)

options(warn=2)

setwd("tpp_estimates/")

exact_folder = "minimal_pref_data"
flow_folder = "minimal_pref_data"
years = c(1983, 1984, 1987, 1990, 1993, 1996, 1998, 2001, 2004, 2007, 2010, 2013)

source("aux_functions.R")

for (year in years) {
  infile_tcp = sprintf("%s/%s_%d.csv", exact_folder, tcp_name(year), year)
  infile_prim = sprintf("%s/prim_%d.csv", exact_folder, year)
  
  outfile_tcp = sprintf("tpp_benchmark_%d.csv", year)
  
  tcp.df = read_csv(infile_tcp)
  prim.df = read_csv(infile_prim)
  
  tcp.df$TPP_ALP = 0
  tcp.df$TPP_ALP_perc = 0
  tcp.df$TPP_LNP = 0
  tcp.df$TPP_LNP_perc = 0
  tcp.df$TPP_est_type = ""
  
  for (i in seq_along(tcp.df$Seat)) {
    seat = tcp.df$Seat[i]
    
    if ((year == 1987) && (seat == "Blaxland")) {
      # Skip
    } else {
      seat_prim.df = filter(prim.df, Seat == seat)
      
      tcp_parties = c(tcp.df$Party1[i], tcp.df$Party2[i])
      tpp_i = tpp_indices(tcp_parties)
      
      do_estimate = 0
      check_primaries = 0
      ignored = 0
      
      if (tcp.df$Est[i] == "Psephos") {
        # Don't have exact TCP.
        if (tpp_i[1] == 1) {
          # TPP contest
          do_estimate = 1
          
          if (tpp_i[2] == 1) {
            ALP_cand = tcp.df$Candidate1[i]
            LNP_cand = tcp.df$Candidate2[i]
          } else {
            ALP_cand = tcp.df$Candidate2[i]
            LNP_cand = tcp.df$Candidate1[i]
          }
        } else {
          # Non-classic.
          check_primaries = 1
        }
      } else {
        # Have exact TCP, but check if it's non-classic.
        if (tpp_i[1] == 0) {
          check_primaries = 1
        } else {
          tcp.df$TPP_est_type[i] = "exact"
        }
      }
      
      if (check_primaries == 1) {
        any_tpp_list = any_tpp(seat_prim.df$Party)
        
        if (any_tpp_list$tpp_possible == 1) {
          # TPP estimate is possible.
          # Get the highest-polling candidates for ALP and LNP.
          
          do_estimate = 1
          
          ALP_i = any_tpp_list$ALP
          LNP_i = any_tpp_list$LNP
          
          ALP_prim.df = seat_prim.df[ALP_i, ]
          LNP_prim.df = seat_prim.df[LNP_i, ]
          
          temp_ALP_cand_i = which(ALP_prim.df$Votes == max(ALP_prim.df$Votes))
          temp_LNP_cand_i = which(LNP_prim.df$Votes == max(LNP_prim.df$Votes))
          
          ALP_cand = seat_prim.df$Candidate[ALP_i[temp_ALP_cand_i]]
          LNP_cand = seat_prim.df$Candidate[LNP_i[temp_LNP_cand_i]]
        } else {
          ignored = 1
        }
      }
      
      if (do_estimate == 1) {
        # Here we gooooo!
        
        ALP_i = which(seat_prim.df$Candidate == ALP_cand)
        LNP_i = which(seat_prim.df$Candidate == LNP_cand)
        
        ALP_votes = seat_prim.df$Votes[ALP_i]
        LNP_votes = seat_prim.df$Votes[LNP_i]
        
        other_seat_prim.df = seat_prim.df[-c(ALP_i, LNP_i), ]
        other_votes = sum(other_seat_prim.df$Votes)
      
        ALP_votes = ALP_votes + other_votes/2
        LNP_votes = LNP_votes + other_votes/2
        
        ALP_perc = ALP_votes / (ALP_votes + LNP_votes)
        LNP_perc = 1 - ALP_perc
        
        tcp.df$TPP_ALP[i] = round(ALP_votes)
        tcp.df$TPP_LNP[i] = round(LNP_votes)
        tcp.df$TPP_ALP_perc[i] = round(100*ALP_perc, 2)
        tcp.df$TPP_LNP_perc[i] = round(100*LNP_perc, 2)
        tcp.df$TPP_est_type[i] = "benchmark"
      }
    }
  }
  
  tpp.df = tcp.df[c("Seat", "TPP_ALP", "TPP_ALP_perc", "TPP_LNP", "TPP_LNP_perc", "TPP_est_type")]
  
  infile_tcp = sprintf("../exact_data/%s_%d.csv", tcp_name(year), year)
  
  exact_tcp.df = read_csv(infile_tcp)
  tpp.df = filter(tpp.df, TPP_est_type == "benchmark")
  
  exact_tcp.df = filter(exact_tcp.df, Seat %in% tpp.df$Seat)

  tpp.df$Exact_TPP_ALP_perc = 0
  tpp.df$Exact_TPP_LNP_perc = 0
  
  for (i in seq_along(tpp.df$Seat)) {
    seat = tpp.df$Seat[i]
    match_i = which(exact_tcp.df$Seat == seat)
    
    if (length(match_i) != 1) {
      stop("Couldn't match TPP")
    }
    
    tcp_parties = c(exact_tcp.df$Party1[match_i], exact_tcp.df$Party2[match_i])
    tpp_i = tpp_indices(tcp_parties)
    
    if (tpp_i[1] == 0) {
      print(sprintf("Non-classic %d %s", year, seat))
    } else {
      if (tpp_i[2] == 1) {
        tpp.df$Exact_TPP_ALP_perc[i] = exact_tcp.df$Vote_perc1[match_i]
        tpp.df$Exact_TPP_LNP_perc[i] = exact_tcp.df$Vote_perc2[match_i]
      } else {
        tpp.df$Exact_TPP_ALP_perc[i] = exact_tcp.df$Vote_perc2[match_i]
        tpp.df$Exact_TPP_LNP_perc[i] = exact_tcp.df$Vote_perc1[match_i]
      }
    }
  }
  
  rho = cor(tpp.df$TPP_ALP_perc, tpp.df$Exact_TPP_ALP_perc)
  err = tpp.df$TPP_ALP_perc - tpp.df$Exact_TPP_ALP_perc
  
  print(sprintf("%d: r = %.4f, mean err = %.2f, mean abs err = %.2f",
                year, rho, mean(err), mean(abs(err))))
}
