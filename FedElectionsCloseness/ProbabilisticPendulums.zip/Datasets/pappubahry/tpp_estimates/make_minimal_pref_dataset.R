# Script to start preparing the TPP estimates.

library(readr)
library(dplyr)

setwd("tpp_estimates/")

options(warn=2)

exact_folder = "../exact_data"
minimal_folder = "minimal_pref_data"

years = c(1919, 1922, 1925, 1928, 1929, 1931, 1934, 1937, 1940, 1943, 1946, 1949, 1951,
          1954, 1955, 1958, 1961, 1963, 1966, 1969, 1972, 1974, 1975, 1977, 1980, 1983,
          1984, 1987, 1990, 1993, 1996, 1998, 2001, 2004, 2007, 2010, 2013)

for (year in years) {
  print(year)
  tcp_name = "tcp"
  if (year > 1990) {
    tcp_name = "tpp"
  }
  
  infile_prim = sprintf("%s/prim_%d.csv", exact_folder, year)
  infile_tcp = sprintf("%s/%s_%d.csv", exact_folder, tcp_name, year)
  infile_prefs = sprintf("%s/prefs_%d.csv", exact_folder, year)
  infile_turnout = sprintf("%s/turnout_%d.csv", exact_folder, year)
  
  outfile_prim = sprintf("%s/prim_%d.csv", minimal_folder, year)
  outfile_tcp = sprintf("%s/%s_%d.csv", minimal_folder, tcp_name, year)
  outfile_prefs = sprintf("%s/prefs_%d.csv", minimal_folder, year)
  outfile_turnout = sprintf("%s/turnout_%d.csv", minimal_folder, year)
  
  file.copy(infile_prim, outfile_prim)
  file.copy(infile_turnout, outfile_turnout)
  
  if (year < 1983) {
    file.copy(infile_tcp, outfile_tcp)
    file.copy(infile_prefs, outfile_prefs)
  } else {
    in_prim.df = read_csv(infile_prim)
    in_prefs.df = read_csv(infile_prefs)
    in_tcp.df = read_csv(infile_tcp)
    
    all_seats = unique(in_prim.df$Seat)
    
    # First remove seats won on primaries
    seats_prim_max.df = summarise(group_by(in_prim.df, Seat),
                                  Max_vote_perc = max(Vote_perc))
    
    primary_wins = seats_prim_max.df$Seat[which(seats_prim_max.df$Max_vote_perc > 50)]
    
    prefs.df = filter(in_prefs.df, !(Seat %in% primary_wins))
    
    # Now end the preference distributions when the winning
    # candidate reaches 50%
    
    seats = unique(prefs.df$Seat)
    
    remove_i = numeric(0)
    exact_seats = character(0)
    
    for (seat in seats) {
      seat_prefs_i = which(prefs.df$Seat == seat)
      seat_prefs.df = prefs.df[seat_prefs_i, ]
      
      seats_count_max.df = summarise(group_by(seat_prefs.df, Count),
                                     Max_vote_perc = max(New_vote_perc, na.rm=TRUE))
      
      completed_count_i = min(which(seats_count_max.df$Max_vote_perc > 50))
      completed_count = seats_count_max.df$Count[completed_count_i]
      
      this_remove_i = seat_prefs_i[which(seat_prefs.df$Count > completed_count)]
      remove_i = c(remove_i, this_remove_i)
      
      seat_prefs.df = filter(seat_prefs.df, To_candidate != "Exhausted")
      if (length(which(seat_prefs.df$Count == completed_count)) == 2) {
        exact_seats = c(exact_seats, seat)
      }
    }
    
    prefs.df = prefs.df [-remove_i, ]
    
    # Flag the non-exact TPP seats.
    
    prim_cands.df = summarise(group_by(in_prim.df, Seat),
                              num_cands = n())
    
    two_cand_seats = prim_cands.df$Seat[which(prim_cands.df$num_cands == 2)]
    exact_seats = c(exact_seats, two_cand_seats)
    
    non_exact_seats = setdiff(all_seats, exact_seats)
    
    in_tcp.df$Est[which(in_tcp.df$Seat %in% non_exact_seats)] = "Psephos"
    
    write.csv(prefs.df, file=outfile_prefs, row.names=FALSE)
    write.csv(in_tcp.df, file=outfile_tcp, row.names=FALSE)
  }
}
